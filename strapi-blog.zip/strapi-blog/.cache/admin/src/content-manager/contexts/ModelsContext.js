import { createContext } from 'react';

const ModelsContext = createContext();

export default ModelsContext;
