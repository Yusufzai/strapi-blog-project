const IS_DISABLED = true;

export default IS_DISABLED;
