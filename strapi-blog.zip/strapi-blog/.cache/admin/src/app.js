export default {
  config: {
    locales: ['fr'],
  },
  bootstrap() {},
};
