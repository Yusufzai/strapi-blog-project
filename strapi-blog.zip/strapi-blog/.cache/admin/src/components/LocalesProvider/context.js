import { createContext } from 'react';

const LocalesProviderContext = createContext();

export default LocalesProviderContext;
