import React from 'react';
import axios from 'axios';
import MarkdownIt from 'markdown-it/lib';

const Postpage = ({post}) => {

  const md = new MarkdownIt();
  const htmlContent = md.render(post.attributes.content);
  
    return (
        <>
          <article>

            <header>
                <h1>{post.attributes.title}</h1>
            </header>
            
            <p dangerouslySetInnerHTML={{__html: htmlContent}}></p>
          </article>
        </>
    )
}

export default Postpage;


export async function getStaticProps({params}) {
  // const postsResult = await axios.get(`http://localhost:1337/api/posts/${params.id}?populate=image`);
  const postsResult = await axios.get(`http://localhost:1337/api/posts/1?populate=image`);

  return {
    props: {
      posts: postsResult.data
      
    }
  }
  
}


export async function getStaticPaths() {
  // const postsRes = await axios.get("http://localhost:1337/api/posts?populate=image");

  // // console.log(postsRes);
  // // console.log(postsRes.data);
  
  // // const paths = postsRes.map((post) => {
  // //   return { params: {id: post.id.toString()} }
  // // });

  // const paths = { params: {id: '1' } }
    
  // return {
  //   paths,
  //   fallback: false
 
  // }

  
  
}

