import React, { useEffect, useState } from 'react';
import BSCard from './Card';
import { Col } from 'react-bootstrap'

const AllPosts = ({ posts }) => {
    // const [latestPosts, setLatestPosts] = useState([]);
    
    // useEffect(() => {
    //     // const p = posts.slice(0, 5)
    //     setLatestPosts(posts.data.slice(0, 5));
    // }, [posts]);

    function renderPostPreview() {
        return posts.data.map((post) => {

            return <Col xl={3} lg={4} sm={3}> <BSCard postTitle={post.attributes.title} postText={post.attributes.content} id={post.id} /></Col>
            
        })
    }
    
    
    return (
        <>
            <h1>Posts</h1>

            {console.log(posts.data[0].id)}
            {/* {console.log(posts)} */}
            {/* {console.log(posts.data.slice(0, 2))} */}
            {renderPostPreview()}
        </>
    )
}

export default AllPosts;