import React from 'react';
import Head from 'next/head'
import MarkdownIt from 'markdown-it/lib';

const Postpage = ({post}) => {

  const md = new MarkdownIt();
  const htmlContent = md.render(post.data.attributes.content);
  
    return (
        <>

      <Head>
        <title>{post.data.attributes.title}</title>
        <meta name="description" content={post.data.attributes.description}/>
        <meta name="keywords" content="HTML,CSS,XML,JavaScript"/>
        <meta name="author" content="CodeTrophy"/>
        <meta name="viewport" content="initial-scale=1.0, width=device-width" />
        {/* <meta name="viewport" content="width=device-width, initial-scale=1.0"></meta> */}
      </Head>
        
        
          <article>
            {/* {console.log(post.data.attributes)} */}
            <header>
                <h1>{post.data.attributes.title}</h1>
            </header>
            
            {/* <p dangerouslySetInnerHTML={{__html: htmlContent}}></p> */}
            <p>{post.data.attributes.content}</p>
          </article>
        </>
    )
}

export default Postpage;





export async function getStaticPaths() {
  // const postsRes = await axios.get("http://localhost:1337/api/posts?populate=image");
  // const postsRes = {"data":[{"id":1,"attributes":{"title":"Welcome To The Blog Post","content":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut nunc gravida, convallis eros at, ultricies arcu. Morbi finibus felis venenatis ipsum interdum hendrerit non non dolor.","createdAt":"2022-01-22T05:00:32.161Z","updatedAt":"2022-01-22T05:08:50.659Z","publishedAt":"2022-01-22T05:00:33.392Z","image":{"data":null}}},{"id":2,"attributes":{"title":"Learn HTML","content":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut nunc gravida, convallis eros at, ultricies arcu. Morbi finibus felis venenatis ipsum interdum hendrerit non non dolor.","createdAt":"2022-01-22T05:02:32.515Z","updatedAt":"2022-01-22T05:02:48.268Z","publishedAt":"2022-01-22T05:02:48.266Z","image":{"data":null}}},{"id":3,"attributes":{"title":"Test Blog Post","content":"Cras imperdiet magna quis nibh placerat vestibulum. Maecenas tellus metus, elementum non sodales eu, faucibus vitae nibh. Vestibulum placerat velit fringilla augue consequat semper. Donec nec lectus ac erat consectetur malesuada ut eget purus.","createdAt":"2022-02-16T11:02:35.309Z","updatedAt":"2022-02-16T11:02:36.121Z","publishedAt":"2022-02-16T11:02:36.118Z","image":{"data":null}}}],"meta":{"pagination":{"page":1,"pageSize":25,"pageCount":1,"total":3}}};

  // console.log(postsRes);
  // console.log(postsRes.data);
  // console.log(postsRes)
  
  // const paths = postsRes.data.map((post) => {
  //   return { params: {id: post.id.toString()} }
  // });


    const res = await fetch(`http://localhost:1337/api/posts?populate=image`)
    const postsRes = await res.json()

    const paths = postsRes.data.map((post) => {
      return { params: {id: post.id.toString()} }
    });

  // const paths = { params: {id: '1' } }
    
  return {
    paths,
    fallback: false
 
  }

  
  
}

export async function getStaticProps({params}) {
  const res = await fetch(`http://localhost:1337/api/posts/${params.id}?populate=image`);
  // const postsResult = await axios.get(`http://localhost:1337/api/posts/1?populate=image`);
  const postsResult = await res.json()
  return {
    props: {
      post: postsResult
      
    }
  }
  
}

