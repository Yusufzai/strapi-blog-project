// Plugins
// import axios from 'axios'
import Head from 'next/head'
import Image from 'next/image'
import styles from '../styles/Home.module.css'

// Reusable Component
// import NavBar from '../components/NavBar';
import BSCard from '../components/Card';
import HomeHeader from '../components/HomeHeader';
import HomeLatestPosts from '../components/HomeLatestPosts';

// Elements
import { Container,Col,Row } from 'react-bootstrap'

// import { Container } from 'react-bootstrap'
// import { Col } from 'react-bootstrap'
// import { Row } from 'react-bootstrap'


export default function Home({posts}) {
  return (
      <>

        <Container className='mt-5'>
            <Row>
              <Col xl={12} lg={12}><HomeHeader/></Col>
            </Row>
        </Container>
      
        
        {/* <NavBar/> */}
        {/* <BSCard postTitle={posts.data[0].attributes.title} postText="sdfsdafe4r"/> */}
      
        {/* <h1>Home</h1> */}
        {/* <h1>{posts.data[0].attributes.title}</h1> */}
        {/* <h1>{posts.data[1].attributes.title}</h1> */}
        {/* <h1>{posts.data[2].attributes.title}</h1> */}
        {/* <h1>{console.log(posts)}</h1>
        <h1>{console.log(posts.data)}</h1>
        <h1>{console.log(posts.data[0].attributes.title)}</h1>
        <h1>{console.log(posts.data[1].attributes.title)}</h1>
        <h1>{console.log(posts.data[2].attributes.title)}</h1> */}
        {/* <h1>{console.log(posts[1])}</h1> */}
        {/* <h1>{console.log(posts[1].title)}</h1> */}
        {/* <h1>{console.log(props.posts.attributes)}</h1> */}

        <Container className='mt-5'>
            <Row>
                <Col xl={3} lg={4} sm={3}>
                    {/* <BSCard postTitle={posts.data[0].attributes.title} postText="sdfsdafe4r"/> */}
                </Col>
                <Col xl={3} lg={4} sm={3}>
                    {/* <BSCard postTitle={posts.data[1].attributes.title} postText="sdfsdafe4r"/> */}
                </Col>
                <Col xl={3} lg={4} sm={3}>
                    {/* <BSCard postTitle={posts.data[2].attributes.title} postText="sdfsdafe4r"/> */}
                </Col>
                <Col xl={3} lg={4} sm={3}>
                    {/* <BSCard postTitle={posts.data[3].attributes.title} postText="sdfsdafe4r"/> */}
                </Col>

                {/* {posts.map((val, i) => (
                    <div className="user">{val}</div>
                ))} */}
                
                <HomeLatestPosts posts={posts} />
            </Row>
        </Container>



        
      </>
  )
}

// This gets called on every request
export async function getServerSideProps() {
  // const postsResult = await axios.get('http://localhost:1337/api/posts');
  // const postsResult = await axios.get('http://localhost:1337/api/posts?populate=image');


  const res = await fetch('http://localhost:1337/api/posts?populate=image');
  // const postsResult = await axios.get(`http://localhost:1337/api/posts/1?populate=image`);
  const postsResult = await res.json()

  // console.log(postsResult);
  // console.log('d');
  
  return {
    props: {
      posts: postsResult
      
    }
  }
}

