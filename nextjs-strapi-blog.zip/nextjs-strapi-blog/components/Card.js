import React from 'react';
import Link from 'next/link';
import { Card } from 'react-bootstrap'
import { Button } from 'react-bootstrap'

const BSCard = (props) => {
    return (
        <>

            <Link href={`/posts/${props.id}`}>
                <Card id={props.id} style={{ width: '18rem' }}>
                    <Card.Img variant="top" src={`http://localhost:1337/uploads/${props.image}`} />
                    <Card.Body>
                        <Card.Title>{props.postTitle}</Card.Title>
                        <Card.Text>
                            {props.postText}
                        </Card.Text>
                        <Button variant="primary">Go somewhere</Button>
                    </Card.Body>
                </Card>
            </Link>
        </>
    )
}

export default BSCard;